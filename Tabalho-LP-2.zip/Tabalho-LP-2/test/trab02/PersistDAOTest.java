/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package trab02;

import java.sql.Connection;
import java.sql.SQLException;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author Usuário
 */
public class PersistDAOTest {
    private Connection con;
     @Before
    public void setUp() throws SQLException {
        con = new ConnectionFactory().establishConnection();
      
    }
     
    @After
    public void tearDown() throws SQLException{
      //  con.rollback();
    }
    
    @Test
    public void deveCadastrarLivroeEncontrarPorTitulo() throws SQLException {
         String titulo = "Teste 1";
        String genero = "Teste Genero";
        String isbn = "Teste Isbn";
        Double preco = 19.0;
        int idEscritor = 1;
        Livro livro = new Livro(titulo, genero, isbn, preco, idEscritor);
        PersistDAO dao = new PersistDAO(con);
        dao.saveLivro(livro);
        Livro teste = dao.getLivroByTitulo("Teste 1");
        assertNotNull(teste);
    }
    
}
